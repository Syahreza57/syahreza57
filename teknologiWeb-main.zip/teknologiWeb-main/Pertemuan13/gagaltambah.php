<!DOCTYPE html>
<html>
<head>
<title>Tambah Mahasiswa</title>
</head>
<body>
<span style="color:red">Gagal menambah data
mahasiswa</span><br>
<a href="tambahmhs.php">Tambah data Mahasiswa</a>
</body>
</html>