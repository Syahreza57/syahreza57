<!DOCTYPE html>
<html>

<head>
    <title>Ubah Matakuliah</title>
</head>

<body>
    <span style="color:red">Gagal mengubah data
        matakuliah</span><br><br>
    <a href="ubahmk.php">Ubah data Matakuliah</a>
</body>

</html>