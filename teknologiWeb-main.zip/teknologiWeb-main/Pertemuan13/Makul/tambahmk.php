<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Data Matakuliah</title>
</head>

<body>
    <h1>Tambah Data Matakuliah</h1>
    <form action="prosestambahmk.php" method="post">
        <table cellpadding="8">
            <tr>
                <td>Kode</td>
                <td><input type="text" name="kode"></td>
            </tr>
            <tr>
                <td>Nama</td>
                <td><input type="text" name="nama"></td>
            </tr>
            <tr>
                <td>SKS</td>
                <td><input type="text" name="sks"></td>
            <tr>
                <td>
                </td>
                <td>
                    <input type="submit" value="Tambah">
                </td>
            </tr>
        </table>

    </form>

</body>

</html>