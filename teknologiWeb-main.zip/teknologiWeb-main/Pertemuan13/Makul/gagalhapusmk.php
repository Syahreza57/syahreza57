<!DOCTYPE html>
<html>

<head>
    <title>Hapus Matakuliah</title>
</head>

<body>
    <span style="color:red">Gagal menghapus data
        matakuliah</span><br><br>
    <a href="hapusmk.php">Hapus data Matakuliah</a>
</body>

</html>